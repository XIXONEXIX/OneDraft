from stacks.registry import STACKS
def test_all_stacks(): assert [c().stack_id for c in STACKS]==[f'{n}.0' for n in range(1,54)]
def test_contracts():
 for c in STACKS:
  assert c().stack_id.endswith('.0')
