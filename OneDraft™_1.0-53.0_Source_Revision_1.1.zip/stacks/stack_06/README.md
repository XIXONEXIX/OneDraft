# OneDraft™ Stack 6.0 — Executable Foundation

Upstream: 5.0

Downstream: 7.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
