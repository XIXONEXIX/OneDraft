"""OneDraft™ Stack 40.0."""
