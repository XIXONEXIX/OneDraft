"""OneDraft™ Stack 27.0."""
