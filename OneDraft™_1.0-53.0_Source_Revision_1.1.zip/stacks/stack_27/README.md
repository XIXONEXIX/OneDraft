# OneDraft™ Stack 27.0 — Identity and Authentication

Upstream: 26.0

Downstream: 28.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
