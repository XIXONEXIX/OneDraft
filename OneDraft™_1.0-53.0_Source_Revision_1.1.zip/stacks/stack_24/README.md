# OneDraft™ Stack 24.0 — Jobs and Workers

Upstream: 23.0

Downstream: 25.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
