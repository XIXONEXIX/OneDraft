"""OneDraft™ Stack 45.0."""
