# OneDraft™ Stack 45.0 — API Gateway

Upstream: 44.0

Downstream: 46.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
