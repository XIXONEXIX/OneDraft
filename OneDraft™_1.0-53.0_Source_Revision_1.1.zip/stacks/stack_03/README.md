# OneDraft™ Stack 3.0 — Technology and Repository Architecture

Upstream: 2.0

Downstream: 4.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
