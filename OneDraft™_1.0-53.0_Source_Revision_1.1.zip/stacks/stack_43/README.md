# OneDraft™ Stack 43.0 — Billing and Entitlements

Upstream: 42.0

Downstream: 44.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
