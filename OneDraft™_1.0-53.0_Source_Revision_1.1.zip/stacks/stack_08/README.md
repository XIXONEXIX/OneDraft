# OneDraft™ Stack 8.0 — Package Architecture

Upstream: 7.0

Downstream: 9.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
