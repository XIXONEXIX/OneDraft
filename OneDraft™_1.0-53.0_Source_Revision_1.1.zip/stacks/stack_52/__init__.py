"""OneDraft™ Stack 52.0."""
