# OneDraft™ Stack 25.0 — Artifacts and Storage

Upstream: 24.0

Downstream: 26.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
