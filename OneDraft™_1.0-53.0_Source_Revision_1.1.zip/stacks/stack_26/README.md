# OneDraft™ Stack 26.0 — Event Bus

Upstream: 25.0

Downstream: 27.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
