# OneDraft™ Stack 15.0 — Service Composition

Upstream: 14.0

Downstream: 16.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
