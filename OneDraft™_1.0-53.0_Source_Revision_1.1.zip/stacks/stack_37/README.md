# OneDraft™ Stack 37.0 — Aria AI Architecture

Upstream: 36.0

Downstream: 38.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
