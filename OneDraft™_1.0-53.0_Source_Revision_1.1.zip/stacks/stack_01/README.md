# OneDraft™ Stack 1.0 — Foundation and System Authority

Upstream: foundation

Downstream: 2.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
