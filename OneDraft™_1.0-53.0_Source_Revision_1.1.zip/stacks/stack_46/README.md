# OneDraft™ Stack 46.0 — Performance and Scalability

Upstream: 45.0

Downstream: 47.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
