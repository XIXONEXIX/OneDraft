# OneDraft™ Stack 11.0 — Commands Transactions Repositories

Upstream: 10.0

Downstream: 12.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
