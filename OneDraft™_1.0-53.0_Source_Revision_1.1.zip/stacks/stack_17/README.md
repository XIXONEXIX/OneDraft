# OneDraft™ Stack 17.0 — Parametric Geometry

Upstream: 16.0

Downstream: 18.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
