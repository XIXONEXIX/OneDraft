# OneDraft™ Stack 39.0 — CAD BIM Standards

Upstream: 38.0

Downstream: 40.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
