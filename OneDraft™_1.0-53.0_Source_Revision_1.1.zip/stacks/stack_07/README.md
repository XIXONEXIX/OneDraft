# OneDraft™ Stack 7.0 — Application Runtime

Upstream: 6.0

Downstream: 8.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
