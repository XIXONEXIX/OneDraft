"""OneDraft™ Stack 48.0."""
