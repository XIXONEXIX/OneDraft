# OneDraft™ Stack 48.0 — SDK and Extensions

Upstream: 47.0

Downstream: 49.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
