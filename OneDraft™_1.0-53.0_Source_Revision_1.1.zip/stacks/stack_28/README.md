# OneDraft™ Stack 28.0 — Authorization

Upstream: 27.0

Downstream: 29.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
