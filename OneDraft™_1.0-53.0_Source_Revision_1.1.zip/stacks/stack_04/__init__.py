"""OneDraft™ Stack 4.0."""
