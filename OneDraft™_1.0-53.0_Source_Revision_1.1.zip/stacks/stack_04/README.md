# OneDraft™ Stack 4.0 — Domain and API Schema

Upstream: 3.0

Downstream: 5.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
