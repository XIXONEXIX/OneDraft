# OneDraft™ Stack 9.0 — Application and Domain Services

Upstream: 8.0

Downstream: 10.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
