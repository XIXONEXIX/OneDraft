"""OneDraft™ Stack 50.0."""
