"""OneDraft™ Stack 32.0."""
