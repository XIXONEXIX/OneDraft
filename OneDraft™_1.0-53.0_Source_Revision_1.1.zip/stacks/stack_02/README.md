# OneDraft™ Stack 2.0 — System Architecture

Upstream: 1.0

Downstream: 3.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
