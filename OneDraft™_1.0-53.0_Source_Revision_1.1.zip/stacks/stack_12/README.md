# OneDraft™ Stack 12.0 — Repository and Core Runtime

Upstream: 11.0

Downstream: 13.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
