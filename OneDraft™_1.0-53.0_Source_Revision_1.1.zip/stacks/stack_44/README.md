# OneDraft™ Stack 44.0 — Multi-Tenant Isolation

Upstream: 43.0

Downstream: 45.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
