# OneDraft™ Stack 36.0 — Lifecycle and Provenance

Upstream: 35.0

Downstream: 37.0

Shared authority remains canonical across Project Model, identity, tenancy, lifecycle, versioning, and provenance.
