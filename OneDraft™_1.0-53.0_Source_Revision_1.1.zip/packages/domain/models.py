from pydantic import BaseModel,Field
from uuid import UUID,uuid4
from typing import Any
class ProjectModel(BaseModel):
 project_id:UUID; version:int=1; elements:dict[str,dict[str,Any]]=Field(default_factory=dict)
