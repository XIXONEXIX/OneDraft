class ArcGISAdapter:
 async def import_features(self,source,project_id): return {'source':source,'project_id':str(project_id),'status':'adapter-ready'}
