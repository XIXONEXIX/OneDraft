class ParametricGeometryEngine:
 async def compute(self,model): return model.model_copy(update={'version':model.version+1})
